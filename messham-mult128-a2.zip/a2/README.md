# Mult 128 - Assignment 3

Daniel Messham

Animal fan page thing

- American Crow
-

# Plan

* [X] Add some images i already have
* [X] Start html
* [X] add cdn links
* [X] structure the html
* [X] add facts and info
* [ ] add proper images
* [X] mess with styling

Reflection
-----------
General
 - It is very hard to get stuff done when you run out of ADHD medication, and have a very needy cat.
  - bootstrap is clearly ment for a certain style, and trying to do anything else gets weird fast.
  - i have memorized a lot of otherwise useless trivia
What went well
 - Bootstraps documentation is easy to follow.
 - once you figure out the syntax making a decent looking page is really easy.
Challenges
 - Trying to deviate from the basic almost minimalist design of bootstrap makes things painful or janky really fast (the navbar is kindof a mess)
 - i need to organize my data better, my bird related memes are split across 3 or 4 drives, might try to repupose a space laptop as a nas and get everything in one place